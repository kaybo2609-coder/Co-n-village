const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'players.json');

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ===== DATABASE (archivo JSON - simple y gratis) =====
function loadPlayers() {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
      fs.writeFileSync(DATA_FILE, '{}');
    }
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) {
    return {};
  }
}

function savePlayers(players) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(players, null, 2));
}

function getPlayer(id) {
  const players = loadPlayers();
  return players[id] || null;
}

function updatePlayer(id, data) {
  const players = loadPlayers();
  if (!players[id]) return null;
  players[id] = { ...players[id], ...data };
  savePlayers(players);
  return players[id];
}

// Crear pueblo inicial
function createVillage() {
  return {
    buildings: {
      house: 1,
      farm: 1,
      mill: 0,
      tower: 0,
      bank: 0
    },
    level: 1
  };
}

// ===== RUTAS =====

// Registro
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password || username.length < 3 || password.length < 4) {
    return res.status(400).json({ error: 'Usuario (min 3) y contraseña (min 4) requeridos' });
  }

  const players = loadPlayers();
  const exists = Object.values(players).find(p => p.username.toLowerCase() === username.toLowerCase());
  if (exists) return res.status(400).json({ error: 'Ese nombre ya existe' });

  const id = uuidv4();
  const hash = await bcrypt.hash(password, 8);

  players[id] = {
    id,
    username,
    password: hash,
    coins: 1000,
    spins: 50,
    shields: 3,
    village: createVillage(),
    attacks: 5,
    lastDaily: null,
    createdAt: new Date().toISOString()
  };
  savePlayers(players);

  res.json({
    success: true,
    player: {
      id,
      username,
      coins: 1000,
      spins: 50,
      shields: 3,
      village: players[id].village,
      attacks: 5
    }
  });
});

// Login
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const players = loadPlayers();
  const player = Object.values(players).find(p => p.username.toLowerCase() === username.toLowerCase());

  if (!player) return res.status(400).json({ error: 'Usuario no encontrado' });

  const valid = await bcrypt.compare(password, player.password);
  if (!valid) return res.status(400).json({ error: 'Contraseña incorrecta' });

  res.json({
    success: true,
    player: {
      id: player.id,
      username: player.username,
      coins: player.coins,
      spins: player.spins,
      shields: player.shields,
      village: player.village,
      attacks: player.attacks
    }
  });
});

// Obtener datos del jugador
app.get('/api/player/:id', (req, res) => {
  const player = getPlayer(req.params.id);
  if (!player) return res.status(404).json({ error: 'Jugador no encontrado' });

  res.json({
    id: player.id,
    username: player.username,
    coins: player.coins,
    spins: player.spins,
    shields: player.shields,
    village: player.village,
    attacks: player.attacks
  });
});

// Girar ruleta
app.post('/api/spin', (req, res) => {
  const { playerId } = req.body;
  const player = getPlayer(playerId);
  if (!player) return res.status(404).json({ error: 'Jugador no encontrado' });
  if (player.spins <= 0) return res.status(400).json({ error: 'No te quedan giros' });

  // Resultados posibles (estilo Coin Master)
  const results = [
    { type: 'coins', value: 50, weight: 25 },
    { type: 'coins', value: 100, weight: 20 },
    { type: 'coins', value: 200, weight: 12 },
    { type: 'coins', value: 500, weight: 5 },
    { type: 'attack', value: 1, weight: 15 },
    { type: 'attack', value: 2, weight: 8 },
    { type: 'shield', value: 1, weight: 10 },
    { type: 'spins', value: 3, weight: 5 }
  ];

  const totalWeight = results.reduce((s, r) => s + r.weight, 0);
  let rand = Math.random() * totalWeight;
  let result = results[0];
  for (const r of results) {
    rand -= r.weight;
    if (rand <= 0) { result = r; break; }
  }

  player.spins -= 1;

  if (result.type === 'coins') player.coins += result.value;
  if (result.type === 'attack') player.attacks += result.value;
  if (result.type === 'shield') player.shields += result.value;
  if (result.type === 'spins') player.spins += result.value;

  updatePlayer(playerId, player);

  res.json({
    success: true,
    result,
    player: {
      coins: player.coins,
      spins: player.spins,
      shields: player.shields,
      attacks: player.attacks
    }
  });
});

// Mejorar edificio
app.post('/api/upgrade', (req, res) => {
  const { playerId, building } = req.body;
  const player = getPlayer(playerId);
  if (!player) return res.status(404).json({ error: 'Jugador no encontrado' });

  const costs = { house: 200, farm: 300, mill: 500, tower: 800, bank: 1200 };
  const cost = (costs[building] || 500) * (player.village.buildings[building] + 1);

  if (player.coins < cost) return res.status(400).json({ error: 'No tienes suficientes monedas', cost });

  player.coins -= cost;
  player.village.buildings[building] = (player.village.buildings[building] || 0) + 1;
  player.village.level = Object.values(player.village.buildings).reduce((a, b) => a + b, 0);

  updatePlayer(playerId, player);

  res.json({
    success: true,
    cost,
    player: {
      coins: player.coins,
      village: player.village
    }
  });
});

// Lista de jugadores para atacar
app.get('/api/targets/:playerId', (req, res) => {
  const players = loadPlayers();
  const me = players[req.params.playerId];
  if (!me) return res.status(404).json({ error: 'No encontrado' });

  const targets = Object.values(players)
    .filter(p => p.id !== req.params.playerId)
    .map(p => ({
      id: p.id,
      username: p.username,
      level: p.village?.level || 1,
      shields: p.shields,
      coins: Math.floor(p.coins * 0.3) // lo que se puede robar
    }))
    .slice(0, 20);

  res.json({ targets });
});

// Atacar
app.post('/api/attack', (req, res) => {
  const { playerId, targetId } = req.body;
  const players = loadPlayers();
  const attacker = players[playerId];
  const target = players[targetId];

  if (!attacker || !target) return res.status(404).json({ error: 'Jugador no encontrado' });
  if (attacker.attacks <= 0) return res.status(400).json({ error: 'No tienes ataques' });

  attacker.attacks -= 1;

  let stolen = 0;
  let message = '';

  if (target.shields > 0) {
    target.shields -= 1;
    message = `¡${target.username} tenía escudo! Lo rompiste.`;
  } else {
    stolen = Math.floor(target.coins * 0.15) + Math.floor(Math.random() * 50);
    stolen = Math.min(stolen, target.coins);
    target.coins -= stolen;
    attacker.coins += stolen;
    message = `¡Saqueaste ${stolen} monedas de ${target.username}!`;
  }

  savePlayers(players);

  res.json({
    success: true,
    message,
    stolen,
    player: {
      coins: attacker.coins,
      attacks: attacker.attacks,
      shields: attacker.shields
    }
  });
});

// Recompensa diaria
app.post('/api/daily', (req, res) => {
  const { playerId } = req.body;
  const player = getPlayer(playerId);
  if (!player) return res.status(404).json({ error: 'No encontrado' });

  const today = new Date().toDateString();
  if (player.lastDaily && new Date(player.lastDaily).toDateString() === today) {
    return res.status(400).json({ error: 'Ya reclamaste la recompensa de hoy' });
  }

  player.spins += 20;
  player.coins += 300;
  player.attacks += 2;
  player.lastDaily = new Date().toISOString();

  updatePlayer(playerId, player);

  res.json({
    success: true,
    message: '¡+20 giros, +300 monedas y +2 ataques!',
    player: {
      coins: player.coins,
      spins: player.spins,
      attacks: player.attacks
    }
  });
});

// Ranking
app.get('/api/ranking', (req, res) => {
  const players = loadPlayers();
  const ranking = Object.values(players)
    .map(p => ({
      username: p.username,
      level: p.village?.level || 1,
      coins: p.coins
    }))
    .sort((a, b) => b.level - a.level || b.coins - a.coins)
    .slice(0, 30);

  res.json({ ranking });
});

// Admin - dar recursos (protegido por clave simple)
app.post('/api/admin/give', (req, res) => {
  const { adminKey, playerId, coins, spins, attacks, shields } = req.body;
  if (adminKey !== (process.env.ADMIN_KEY || 'admin123')) {
    return res.status(403).json({ error: 'No autorizado' });
  }

  const player = getPlayer(playerId);
  if (!player) return res.status(404).json({ error: 'Jugador no encontrado' });

  if (coins) player.coins += Number(coins);
  if (spins) player.spins += Number(spins);
  if (attacks) player.attacks += Number(attacks);
  if (shields) player.shields += Number(shields);

  updatePlayer(playerId, player);
  res.json({ success: true, player });
});

// Ruta principal
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Servidor Coin Master Free corriendo en puerto ${PORT}`);
});
