# Coin Village - Estilo Coin Master (Gratis)

Juego multijugador gratis inspirado en Coin Master.

## Características
- Registro e inicio de sesión
- Girar ruleta (monedas, ataques, escudos, giros)
- Construir y mejorar pueblo
- Atacar y saquear a otros jugadores
- Ranking
- Recompensa diaria
- Se instala en el celular como App (PWA)

## Cómo subirlo GRATIS a Render.com (paso a paso)

### Desde el celular o PC:

1. Entra a https://github.com y crea una cuenta (si no tienes)
2. Crea un repositorio nuevo llamado `coin-village`
3. Sube TODOS los archivos de esta carpeta al repositorio
4. Entra a https://render.com y regístrate con tu cuenta de GitHub
5. Pulsa **New +** → **Web Service**
6. Conecta el repositorio `coin-village`
7. Configuración:
   - Name: coin-village
   - Runtime: Node
   - Build Command: `npm install`
   - Start Command: `npm start`
8. Pulsa **Create Web Service**
9. Espera 2-5 minutos
10. Te dará una URL tipo: `https://coin-village-xxxx.onrender.com`

### Instalar en el celular:
1. Abre esa URL en Chrome (Android) o Safari (iPhone)
2. Android: menú → "Añadir a pantalla de inicio"
3. iPhone: botón Compartir → "Añadir a pantalla de inicio"

¡Listo! Ya tienes el juego instalado como app.

## Admin
Para dar recursos a un jugador (desde código o Postman):
POST /api/admin/give
Body: { "adminKey": "admin123", "playerId": "...", "coins": 5000, "spins": 100 }
